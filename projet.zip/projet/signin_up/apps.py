from django.apps import AppConfig


class SigninUpConfig(AppConfig):
    name = 'signin_up'
